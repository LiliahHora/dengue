document.getElementById("meuBotao").addEventListener("click", function() {
    alert("O botão foi clicado!");
  });
  